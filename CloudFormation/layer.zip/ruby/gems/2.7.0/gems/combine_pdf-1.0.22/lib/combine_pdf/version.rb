module CombinePDF
  VERSION = '1.0.22'.freeze
end
