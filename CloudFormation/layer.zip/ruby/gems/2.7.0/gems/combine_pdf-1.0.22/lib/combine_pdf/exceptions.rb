module CombinePDF
  class EncryptionError < StandardError
  end
end
