module Test
  module Unit
    VERSION = "3.5.5"
  end
end
